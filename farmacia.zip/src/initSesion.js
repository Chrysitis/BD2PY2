import React from 'react'
import { useHistory } from 'react-router-dom'
import axios from 'axios'

const InitSesion = () => {

  //const [renderData, setData] = useHistory('');
  /* ----- */
  var farmasData = [];
  var email = 'a';
  var pass = 'a';
  var authenticate = false;
  const history = useHistory();
  //getRequest();
  function getInputEmail(val) {
    email = val.target.value;
  }
  function getInputPass(val) {
    pass = val.target.value;
  }
  async function getRequest() {
    var url = 'http://localhost:8080/api/Farmaceuticos/' + email +'&' + pass;
    let res = await axios.get(url);
    farmasData = res.data;
    if(farmasData.length === 1) {
      authenticate = true;
    }
  }
  const authentication = () => {
    getRequest();
    if(authenticate) {
      history.push("/farmaceutico");
    }else {
      alert('Eeeeeeeeerr')
    }
  }
  return (
    <div className="initSesionFormCenter">
      <div className="initSesionForm">
        <h1 className="initSesionText">Inicio de Sesión</h1>
        <div className="inputForm">
          <h2>Usuario</h2>
          <input onChange={getInputEmail} className="inputTags"></input>
          <h2>Contraseña</h2>
          <input onChange={getInputPass} className="inputTags" type='password' ></input>
          <button onClick={authentication} className="submitButton">Iniciar Sesion</button>
        </div>
      </div>
    </div>
  )
}
export default InitSesion;