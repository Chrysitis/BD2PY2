import React from "react";

function Butt(props) {
    return(
      <button className="butt">
        <h1> {props.text} </h1>
      </button>
    );
  }

  export default Butt;