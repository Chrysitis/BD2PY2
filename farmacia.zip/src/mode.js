import React from "react";
import { Link } from "react-router-dom";
function Mode() {

  return (
    <div className="mainScreen">
      <button className="butt">
        <Link to="/MainContent" className="hyperLinkStyle"> Sucursal Limón </Link>
      </button>
      <button className="butt"> 
        <Link to="/MainContent" className="hyperLinkStyle"> Sucursal SJ </Link>
      </button>
      <button className="butt">
        <Link to="/initSesion" className="hyperLinkStyle"> Farmaceúticos </Link>
      </button>
    </div>
  )
}
export default Mode;

/*

      <div className="mainScreen">
        <Butt text="Sucursal San José"></Butt>
        <Butt text="Sucursal Limón"></Butt>
        <Butt text="Farmaceúticos"></Butt>
      </div>

*/