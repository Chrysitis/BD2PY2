import React from 'react';
import './App.css';
import Header from "./Header";
import MainContent from "./Content";
import Footer from "./Footer";
import Mode from "./mode";
import Contact from "./contact";
import InitSesion from "./initSesion";
import Farmaceutico from './farmaceuticoMode';
import { Route } from 'react-router-dom';


function App() {
  return (
    <div className="container">
      <Header />
      <Route exact path="/" component={Mode} />
      <Route exact path="/contact" component={Contact} />
      <Route exact path="/MainContent" component={MainContent} />
      <Route exact path="/initSesion" component={InitSesion} />
      <Route exact path="/farmaceutico" component={Farmaceutico}/>
      <Footer />
    </div>
  );
}

export default App;