import React, { useEffect, useState } from 'react'

const Productos = () => {

    //const url = 'http://localhost:8090/api/Users/19';
    const [producto, setProducto] = useState([])
  
    useEffect(() => {
      //axios.get(url).then(response => {
      getData()
  
    }, [])
    const getData = async () => {
      const data = await fetch('http://localhost:8080/api/Productos')
      const product = await data.json()
      console.log(product)
      setProducto(product)
    }
    const listProductos = producto.map((item) =>
      <div className="card" key={item.productoDes}>
        <div className="card_img">
          <img alt='' src={item.foto} />
        </div>
        <div className="card_header">
          <h2>{item.productoDes}</h2>
          <p className="price">{item.precio}<span>₡</span></p>
          <div className="btn">Add to cart</div>
        </div>
      </div>
    );
    return (
      <div className="main_content">
        <div className="fLogo">
          <img alt='' src ={'https://i0.wp.com/www.logoworks.com/blog/wp-content/uploads/2014/03/fruit-vegetable-logos-templates-logo-designs-037.png?fit=325%2C260&ssl=1'} />
        </div>
        {listProductos}
      </div>
    )
  }

  export default Productos;