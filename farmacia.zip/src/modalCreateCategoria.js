import React from 'react';
import axios from 'axios';

const ModalCreateCategoria = props => {

  var categoria = '';
  function getInputCategory(val) {
    categoria = val.target.value;
  }
  async function postRequest() {
    // https://zetcode.com/javascript/axios/
    //let payload = {IDCategoria: '1', productoDes: 'Antifludes', precio: 4365, imagen: 'https://vonvacr.com/tiendabk/152-large_default/antifludes-12-und.jpg' };
    let catData = {categoria: categoria};
    let res = await axios.post('http://localhost:8080/api/Categorias', catData);
    let data = res.data;
    console.log(data);
    //redirect();
  }
  return (
    <div className="modal">
      <div className="modal-content">
        <div className="modal-header">
          <h4 className="modal-title">Nueva Categoría</h4>
        </div>
        <div className="modal-body">
          <h3>Categoría:</h3>
          <input onChange={getInputCategory} className="inputCategoria"></input>
        </div>
        <div className="modal-footer">
          <button onClick={postRequest} className="modal-button">Crear</button>
        </div>
      </div>
    </div>
  )
}

export default ModalCreateCategoria;