import React from "react";
//import Butt from './testFunc'

function aboutUsInfo() {

    return (
        <div>
            <div className="aboutForm">
                <h1 className="hsMargin">Farmacia La Genérica</h1>
                <h1 className="hsMargin">Email: lagenerica@gmail.com</h1>
                <h1 className="hsMargin">Teléfono: 20212223</h1>
                <h1 className="hsMargin">Ubicación: Limón y San José</h1>
			</div>
        </div>
    )
}
export default aboutUsInfo;