import React, { useState } from 'react'
import ModalCategoria from './modalCreateCategoria';
import ModalProducto from './modalCreateProduct';
import ModalManejarInventario from './modalManejarInventario';
import ModalConsultarFacturas from './modalConsultarFacturas'


function Farmaceutico() {

  const [modalName, setModal] = useState();

  const NuevoProductoForm = () => {
    setModal(ModalCategoria)
  }
  const NuevaCategoriaForm = () => {
    setModal(ModalProducto)
  }
  const ManejarInventarioForm = () => {
    setModal(ModalManejarInventario)
  }
  const ConsultarFacturasForm = () => {
    setModal(ModalConsultarFacturas)
  }

  return (
    <div className="mainFarmaceutico">
      <div className="mainFarmaceuticoActions">
        <button onClick={NuevoProductoForm} className="button">Nueva Categoría</button>
        <button onClick={NuevaCategoriaForm} className="button">Nueva Producto</button>
        <button onClick={ManejarInventarioForm} className="button">Manejar Inventario</button>
        <button onClick={ConsultarFacturasForm} className="button">Consultar Facturas</button>
      </div>
      {modalName}
    </div>
  )
}

export default Farmaceutico;