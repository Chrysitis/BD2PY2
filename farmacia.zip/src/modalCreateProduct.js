import React from 'react';
//import { useHistory } from 'react-router-dom';
import axios from 'axios';

const ModalCreateProducto = props => {

  //const [title, setTitle] = useState('')
  var idCategory = '';
  var productoDescripcion = '';
  var productoPrecio = '';
  var productoImagen = '';
/*  const history = useHistory();

  const redirect = () => {
    history.push("/farmaceutico");
} */
  function getInputCategory(val) {
    idCategory = val.target.value;
  }
  function getInputDes(val) {
    productoDescripcion = val.target.value;
  }
  function getInputPrecio(val) {
    productoPrecio = val.target.value;
  }
  function getInputImagen(val) {
    productoImagen = val.target.value;
  }
  async function postRequest() {
    // https://zetcode.com/javascript/axios/
    //let payload = {IDCategoria: '1', productoDes: 'Antifludes', precio: 4365, imagen: 'https://vonvacr.com/tiendabk/152-large_default/antifludes-12-und.jpg' };
    //let productData = {IDCategoria: idCategory, productoDes: productoDescripcion, precio: productoPrecio, foto: productoImagen};
    let test = {IDCategoria: idCategory, productoDes: productoDescripcion, precio: productoPrecio, foto: productoImagen}
    let res = await axios.post('http://localhost:8080/api/Productos', test);
    let data = res.data;
    console.log(data);
    //redirect();
  }


  return (
    <div className="modal">
      <div className="modal-content">
        <div className="modal-header">
          <h4 className="modal-title">Nuevo Producto</h4>
        </div>
        <div className="modal-body">
          <h3>Categoría:</h3>
          <input onChange={getInputCategory} className="inputCategoria" ></input>
          <h3>Nombre:</h3>
          <input onChange={getInputDes} className="inputCategoria"></input>
          <h3>Precio:</h3>
          <input onChange={getInputPrecio} className="inputCategoria"></input>
          <h3>Imagen:</h3>
          <input onChange={getInputImagen} className="inputCategoria"></input>
        </div>
        <div className="modal-footer">
          <button className="modal-button" onClick={postRequest}>Agregar</button>
        </div>
      </div>
    </div>
  )
}

export default ModalCreateProducto;