
import React from 'react'
import Productos from "./productsContent"

function test() {
  return (
    <div>
      <Productos />
    </div>
    
  )
}

export default test;