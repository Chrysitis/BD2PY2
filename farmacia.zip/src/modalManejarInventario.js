import React from 'react'
import axios from 'axios'

const ModalManejarInventario = () => {

  //const [show, setshow] = useState(false);
  //var productsData = [];
  //var productNames = [];
  var id = '';
  var cant = '';
  function getInputProduct(val) {
    id = val.target.value;
  }
  function getInputCantidad(val) {
    cant = val.target.value;
  }
  async function putRequest() {
    // https://zetcode.com/javascript/axios/
    var url = 'http://localhost:8080/api/Inventario/' + id;
    let catData = {IDProducto: id, cantidad: cant};
    let res = await axios.put(url, catData);
    let data = res.data;
    console.log(data);
  }
  
  return (
    <div className="modal">
      <div className="modal-content">
        <div className="modal-header">
          <h4 className="modal-title">Nueva Categoría</h4>
        </div>
        <div className="modal-body">
          <h3>Producto:</h3>
            <input onChange={getInputProduct} className="inputCategoria"></input>
          <h3>Existencias:</h3>
          <input onChange={getInputCantidad} className="inputCategoria"></input>
        </div>
        <div className="modal-footer">
          <button onClick={putRequest} className="modal-button">Guardar</button>
        </div>
      </div>
    </div>
  )
}

export default ModalManejarInventario;