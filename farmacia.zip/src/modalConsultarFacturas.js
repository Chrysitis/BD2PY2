import React from 'react'

function ModalConsultarFacturas() {
  return (
    <div className="modal">
      <div className="modal-content">
        <div className="modal-header">
          <h4 className="modal-title">Nuevo Producto</h4>
        </div>
        <div className="modal-body">
          <h3>Cliente:</h3>
          <select className="inputCategoria"></select>
          <h3>Fecha del:</h3>
          <input type="date" className="inputCategoria"></input>
          <h3>Fecha al:</h3>
          <input type="date" className="inputCategoria"></input>
          <h3>Producto:</h3>
          <select className="inputCategoria"></select>
        </div>
        <div className="modal-footer">
          <button className="modal-button">Consultar</button>
        </div>
      </div>
    </div>
  )
}

export default ModalConsultarFacturas;