const dboperations = require('./dboperations');
var db = require('./dboperations');
var Productos = require('./productos');

/*
dboperations.getProductos().then(result => {
	console.log(result);
})
*/


var express = require('express');
var bodyParser = require('body-parser');    // To parse request and response body
var cors = require('cors');                 //
const { request, response } = require('express');
var app = express();
var router = express.Router();

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cors());
app.use('/api', router);

router.use((request, response, next) => {
	console.log('middleware');
	next();
})

router.route('/Productos').get((request, response) => {
	dboperations.getProductos().then(result => {
		//console.log(result);
		response.json(result[0]);
	})
})

router.route('/Productos/:id').get((request, response) => {
	dboperations.getProductoByID(request.params.id).then(result => {
		//console.log(result);
		response.json(result[0]);
	})
})

router.route('/Productos/:IDCategoria,:productoDes,:precio,:imagen').post((request, response, next) => {
	dboperations.createProducto(request.params.IDCategoria, 
		request.params.productoDes. request.params.precio, request.params.imagen).then(result => {
			response.json(result[0]);
		})
	});
	
/*
router.post('/Productos', (req, res) => {
	const product = {
		idProducto: req.body.idProducto,
		idCategoria: req.body.idCategoria,
		descripcion: req.body.descripcion,
		precio: req.body.precio,
		imagen: req.body.imagen
	}
	res.push(product)
}) */

	var port = process.env.PORT || 8080;
	app.listen(port);
	console.log('Products API is running at ' + port);