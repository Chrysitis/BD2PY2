const config = {
    user: 'sa',
    password: '12345',
    server: 'localhost',
    database: 'FarmaciaLaGenerica',
    options: {
        trustedconnection: true,
        enableArithAbort: true,
        instancename: 'MSI',
        trustServerCertificate: true
    },
    port: 1433
}

module.exports = config;