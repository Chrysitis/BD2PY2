class Productos {

    constructor(IDProducto, IDCategoria, productoDes, precio, imagen) {
      this.IDProducto = IDProducto;
      this.IDCategoria = IDCategoria;
      this.productoDes = productoDes;
      this.precio = precio;
      this.imagen = imagen;
    }
  }
  
  module.exports = Productos;