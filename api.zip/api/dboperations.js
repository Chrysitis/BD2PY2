var config = require('./dbconfig');
const sqlCon = require('mssql');

async function getProductos() {

  try {
    let pool = await sqlCon.connect(config);
    let productos = await pool.request().query("SELECT * FROM Productos");
    return productos.recordsets;
  }
  catch (err) {
    console.log(err)
  }
}

async function getProductoByID(productoID) {

  try {
    let pool = await sqlCon.connect(config);
    let producto = await pool.request()
      .input('productoIDParam', sqlCon.Int, productoID)
      .query("SELECT * FROM Productos WHERE IDProducto = @productoIDParam");
    return producto.recordsets;
  }
  catch (err) {
    console.log(err)
  }
}

async function createProducto(IDCategory, productDes, precio, imagen) {

  try {
    let pool = await sqlCon.connect(config);
    let producto = await pool.request()
      .input('IDCategoryParam', sqlCon.Int, IDCategory)
      .input('productDesParam', productDes)
      .input('precioParam', sqlCon.Int, precio)
      .input('imagenParam', imagen)
      .query("EXECUTE InsertarProducto @IDCategoryParam, @productDesParam, @precioParam, @imagenParam");
    return producto.recordsets;
  }
  catch (err) {
    console.log(err)
  }
}

module.exports = {
  getProductos: getProductos,
  getProductoByID: getProductoByID,
  createProducto: createProducto
}